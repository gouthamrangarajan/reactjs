function SidePanel() {

    return (
        <div className='hidden lg:flex lg:w-1/6 py-2 px-4  text-gray-700 flex-col pt-12 space-y-4
                        h-screen'>
            <span className="text-gray-600 font-semibold">Action Items</span>

        </div>
    )
}

export default SidePanel